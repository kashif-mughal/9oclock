
<div class="bread_crumb">
    <div class="container">
        <div class="row d-block">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Pages</a></li>
                    <li class="breadcrumb-item">Brand Stores</li>
                </ol>
            </nav>
            <h3 class="mb-0">Brand Stores</h3>
        </div>
    </div>
</div>

<!-- Bread Crumb -->


<section class="main-content">
    <div class="container">  
        <div class="row">
            <div class="col-sm-12">
                <div class="card" style="margin-top: 20px;">
                    <div class="card-body" style="padding:50px;">
                        <h3 class="mb-4">Brand Stores</h3>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus tristique ultrices felis, nec maximus quam tempus eu. Sed volutpat ante finibus nulla interdum, quis auctor sem vehicula. Sed scelerisque ligula sit amet metus aliquet tincidunt. Phasellus elit lorem, lobortis eget nunc vel, sollicitudin vulputate libero. Etiam congue, eros ac facilisis porta, velit augue consectetur nunc, sed tincidunt neque purus eu nibh. Nunc sed ullamcorper eros. Curabitur egestas fringilla ligula, ac ornare ante. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nullam elit leo, interdum in venenatis quis, dictum sit amet purus. Maecenas rutrum euismod rutrum. Pellentesque vehicula, urna viverra sodales maximus, purus odio fermentum dui, ac vulputate eros tortor ornare orci. Integer dignissim nibh tortor, sit amet tempor arcu sollicitudin nec. Quisque quis accumsan leo, non sollicitudin augue. Etiam porta eleifend elit.

                        Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Integer pretium vitae nisl quis vestibulum. Quisque bibendum ex id euismod scelerisque. Donec vel sem ornare, bibendum mauris et, vestibulum augue. Donec sed nisl nulla. Sed egestas dapibus enim, in ultricies erat mattis in. Phasellus finibus faucibus eros. Donec venenatis mattis est. Integer ornare purus risus, et congue erat molestie nec. Aliquam venenatis dui ut venenatis volutpat. Nam at tempus mi. Vivamus sed mattis ante. Quisque vel felis nec augue dictum auctor nec nec ante. Cras venenatis scelerisque eleifend. Vestibulum eu ligula a elit finibus aliquam. Curabitur quis purus nec mauris hendrerit pharetra.

                        Aliquam gravida pellentesque metus, quis ullamcorper ligula convallis ac. Cras nec elit et mauris commodo porta quis id felis. Integer accumsan pulvinar congue. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Phasellus tincidunt malesuada augue, sit amet commodo odio vehicula ac. Aliquam aliquet malesuada ipsum, in eleifend lacus commodo non. Fusce id massa pulvinar, laoreet leo vel, semper arcu. Quisque fermentum commodo felis. Mauris ut auctor nisi, porta vulputate nisi. Interdum et malesuada fames ac ante ipsum primis in faucibus. Maecenas quis nisl mi. Donec a elementum enim. Donec luctus, odio sed pretium consectetur, neque velit efficitur urna, a pharetra libero eros non tellus.

                        Proin sit amet metus eu nisi lobortis placerat eu et dolor. Donec tincidunt dictum commodo. Mauris varius felis massa, lacinia lobortis elit varius sed. Maecenas enim nisl, bibendum nec nulla quis, dignissim tincidunt metus. Nullam orci justo, porta quis est a, placerat malesuada ipsum. Sed id viverra orci. Maecenas suscipit lectus vel augue fermentum auctor. Ut congue semper finibus. Nulla facilisi. Suspendisse gravida ultrices purus quis semper. Integer scelerisque augue in iaculis eleifend. Morbi id fermentum quam.

                        Interdum et malesuada fames ac ante ipsum primis in faucibus. Nulla in lacus hendrerit, fermentum erat id, auctor quam. Phasellus faucibus porta finibus. Aliquam risus dolor, lacinia in elit vel, tempus euismod augue. Proin ac dolor magna. Aliquam erat volutpat. Vestibulum tempus, sapien id vestibulum cursus, erat erat dignissim purus, id tempor ex enim sit amet neque. Pellentesque sit amet venenatis metus, mollis rhoncus quam. Nunc arcu ex, pulvinar ut interdum sed, iaculis sit amet nunc. Mauris eros erat, volutpat quis libero non, egestas aliquet eros. Nunc feugiat purus id lectus sodales sagittis. Nullam mauris justo, fermentum eu mattis vel, fermentum in leo. Nunc et magna libero.
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>