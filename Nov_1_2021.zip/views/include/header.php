<?php
$CI = & get_instance();
$CI->load->model('Users');
$users = $CI->Users->profile_edit_data();
if(is_array($users) && !empty($users[0])){
  $users = $users[0];
}else{
  $users = null;
}

$CI->load->library('lcategory');
$menuCatList = $CI->lcategory->get_category_hierarchy();
?>
<style type="text/css">
   .emptyCart{
      background: red;
      padding: 20px;
      margin: 35px;
      text-align: center;
      border-radius: 10px;
      color: white;
      font-weight: 400;
      font-size: 20px;
      min-width: 360px;
   }
   .nothing-to-show{
    background: #cc0808;
    color: white;
    border-radius: 4px;
    padding: 10px;
    text-align: center;
   }
   .left-menu-head{
    padding: 20px 40px !important;
   }
   .error{
    color: red;
   }
   .select2-container--default .select2-results__option--highlighted[aria-selected]{
    background-color: var(--secondary-color);
   }

   .dropdown:hover .dropdown-menu{
      display: block;
   }
   #profileDropdown .dropdown-menu{
      margin-top: 1px;
      transition: 0.5s ease-in-out;
      border-radius: 2px;
      padding: 0px;
   }
   #profileDropdown a.dropdown-item {
      padding: 0.8rem 1.2rem;
   }
   #profileDropdown a.dropdown-item:hover {
      background-color: var(--main-color) !important;
      color: #fff;
   }
   .button-primary{
    background-color: var(--main-color);
   }
   .button-primary:hover{
    background-color: #0c0792;
   }
</style>
<div class="bg-overlay" style="display: none; position: fixed; top: 0; background-color:#000; width: 100%; height: 100vh; z-index: 1999; opacity: 0.8;"></div>
<!-- Script for the use of auto complete search START-->
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<!-- Script for the use of auto complete search  END-->
<!-- Sidebar -->
    
    <div id="mySidenav" class="sidenav">
        <div class="sidenav-content">
            <a href="javascript:void(0)" class="closebtn" id="btn-close-sidebar">&times;</a>
            <h3 class="sidebar-heading"><?php echo !is_null($users) ? "Welcome, ".$users['first_name'].'&nbsp;'.$users['last_name'] : "<a href='".base_url()."Dashboard/user_authentication_email'>Login or Register</a>"?></h3>

            <div class="sidebar-menu">
                <div class="accordion border-b-primary" id="accordionExample">
                    <div class="card border-none">
                        <div class="card-header p-2 sidebar-menu-title p-0" id="headingOne">
                            <a href="javascript:void(0)" class="btn-block d-flex align-items-center p-0" type="button" data-toggle="collapse" 
                                data-target="#collapseOne"
                                aria-expanded="true" aria-controls="collapseOne">
                                <img src="<?php echo base_url() ?>assets/img/sidenav-toggle.png" class="d-inline pr-4" alt="">
                                <h4 class="d-inline">Shop Categories</h4>
                                <img src="<?php echo base_url() ?>assets/img/sidenav-chevron.png" class="d-inline ml-auto" alt="">  
                            </a>
                        </div>
                
                        <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                            <div class="card-body p-0">
                               <ul class="sidebar-menu-items navbar-nav mb-3 ml-4">
                                <?php foreach($menuCatList as $key => $value) {?>
                                   <li><a target="_blank" href="<?=base_url('Cproduct/products?categoryId='.$value->catId) ?>"><?=$key?></a></li>
                                <?php } ?>
                               </ul>
                            </div>
                        </div>
                    </div>

                  </div>

                    <?php if(!is_null($users)){?>
                       <div class="card border-none">
                           <div class="card-header p-2" id="headingTwo"> 
                               <div class="card-header sidebar-menu-title p-0" id="headingOne">
                                   <a href="<?=base_url("User/edit_profile")?>" class="btn-block bg-transparent d-flex align-items-center p-0" type="button">
                                       <img src="<?php echo base_url() ?>assets/img/profile.png" class="d-inline pr-4" alt="">
                                       <h4 class="d-inline">Profile</h4>
                                   </a>
                               </div>
                           </div>
                       </div>
                       <div class="card border-none">
                           <div class="card-header p-2" id="headingTwo">
                               <div class="card-header sidebar-menu-title p-0" id="headingOne">
                                   <a href="<?=base_url("Corder/my_order")?>" class="btn-block bg-transparent d-flex align-items-center p-0" type="button"
                                       >
                                       <img src="<?php echo base_url() ?>assets/img/my_order_history.png" class="d-inline pr-4" alt="">
                                       <h4 class="d-inline">My Order History</h4>
                                   </a>
                               </div>
                           </div>
                       </div>
                       <div class="card border-none">
                           <div class="card-header p-2" id="headingTwo">
                               <div class="card-header sidebar-menu-title p-0" id="headingOne">
                                   <a href="<?=base_url("Corder/track_order_form")?>" class="btn-block bg-transparent d-flex align-items-center p-0" type="button"
                                       >
                                       <img src="<?php echo base_url() ?>assets/img/track_your_order.png" class="d-inline pr-4" alt="">
                                       <h4 class="d-inline">Track Your Order</h4>
                                   </a>
                               </div>
                           </div>
                       </div>
                    <?php }?>
                    <div class="card border-none">
                        <div class="card-header p-2" id="headingTwo">
                            <div class="card-header sidebar-menu-title p-0" id="headingOne">
                                <a href="tel:+44 01793 694088" class="btn-block bg-transparent d-flex align-items-center p-0" type="button"
                                    >
                                    <img src="<?php echo base_url() ?>assets/img/call_us.png" class="d-inline pr-4" alt="">
                                    <h4 class="d-inline">Call Us</h4>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="card border-none">
                        <div class="card-header p-2" id="headingTwo">
                            <div class="card-header sidebar-menu-title p-0" id="headingOne">
                                <a href="<?= is_null($users) ? base_url('Dashboard/user_authentication_email') : base_url('Dashboard/logout') ; ?>" class="btn-block bg-transparent d-flex align-items-center p-0" type="button"
                                    data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    <img src="<?php echo base_url() ?>assets/img/sign-in.png" class="d-inline pr-4" alt="">
                                    <?php if(is_null($users)){?>
                                       <h4 class="d-inline">Sign In</h4>
                                    <?php } else{?>
                                       <h4 class="d-inline">Sign Out</h4>
                                    <?php } ?>
                                </a>
                            </div>
                        </div>
                    </div>
                      <div class="card-header sidebar-menu-title p-0 text-left" id="headingOne">
                     <h4>Follow Us</h4>
                  </div>
                  <div class="row" style=" margin-left: 0px;">
                     <a href="https://www.facebook.com/pages/category/Shopping---Retail/9-Oclock-Shop-123238661844155/"><i class="fab fa-facebook-square fa-1x"></i></a>
                     <div class="socialmedia-footer">|</div>
                     <a href="https://twitter.com/9oClockpk"><i class="fab fa-twitter-square fa-1x"></i></a>
                      <div class="socialmedia-footer">|</div>
                     <a href="#"><i class="fab fa-whatsapp-square fa-1x"></i></a>
                  </div>

            </div>
        </div>
    </div>
    
    <!-- Sidebar -->

<!-- Sidebar Ends -->

<div class="section-head" style="position: fixed; top: 0; width: 100%; z-index: 21;">

      <div class="top-bar">
         <div class="container">
            <div class="row">
                <marquee>
               <nav class="navbar navbar-expand-sm ml-md-auto px-2 px-md-0">
                  <ul class="navbar-nav">
                     <li class="nav-item">
                        <a class="nav-link" href="javascript:void(0)" id="promotionText" role="button"><?=$Web_settings[0]["promotion_text"]?></a>
                     </li>
                  </ul>
               </nav>
                </marquee>
            </div>
         </div>
      </div>
      <div class="main-nav bg-light">
         <div class="container">
            <div class="row align-items-center py-1 py-md-2 pb-sm-0">
               <!-- Brand Logo & Sidebar Button -->
               <div class="col-lg-2 col-md-9 col-sm-7 mb-sm-4 mb-md-2 mb-lg-0 col-8 order-1 text-center" id="header-logo">
                  <div class="logo-container d-flex flex-row align-item-center 
                     justify-content-start justify-content-md-start justify-content-sm-start">
                     <div class="logo ml-2">
                        <div style="cursor: pointer;" class="logo_content text-center" onclick="window.location.href = '<?=base_url();?>'">
                           <!-- <img src="<?php //echo base_url() ?>assets/img/logo-white.png" alt="9o'Clock" class="img-fluid d-block"> -->
                           <img src="<?php echo base_url() ?>assets/img/Logo.png" alt="9oClock" class="d-block" style="max-width: 156px; width:100%; height: auto;">

                           <!-- <p class="text-white tag-line mb-0">Inventing Tomorrow</p>  -->
                        </div>
                     </div>
                  </div>
               </div>
               <!-- Brand Logo & Sidebar Button End -->
               <!-- Search Bar -->
               <div class="col-lg-8 col-md-12 col-sm-12 order-lg-2 order-3 text-lg-left text-right align-item-center">
                  <div class="header_search">
                     <div class="header_search_content">
                        <div class="header_search_form_container">
                           <form id="searchform" action="<?=base_url('cproduct/products')?>" method="get">
                              <div class="input-group mb-1">
                                 <input type="text" name="q" id="q" class="form-control font-weight-400 border-none" placeholder="I'm Shopping for..." onfocus="this.value=''">
                                 <div class="input-group-append">
                                    <button class="btn btn-outline-secondary button-primary text-white border-none px-4 font-size-14" style="border-radius: 0 0.25rem 0.25rem 0;" type="submit">
                                       Search
                                       <!-- <i class="fas fa-search"></i> -->
                                    </button>
                                 </div>
                              </div>
                              <input type="hidden" name="categoryId" id="categoryId">
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- Search Bar Ends -->
                  <!-- Phone Number & Add to Cart Button -->
                  <!-- <div class="col-lg-3 col-md-6 col-sm-5 mb-sm-2 order-lg-3 order-2 text-lg-left text-left pl-1"> -->
                  <div class="col-lg-2 col-md-3 col-sm-5 mb-sm-2 order-lg-3 order-2 col-4" id="header-buttons">
                     <div class="d-flex align-items-center justify-content-between">

                        <div class="phone_cart">
                           <!-- <i class="fas fa-user" id="user_icon"></i> -->
                           <div class="dropdown" id="profileDropdown">
                              <a href="<?php echo is_null($users) ? base_url('dashboard/user_login_email') : "javascript:void(0)";?>">
                                 <!-- <img src="<?php //echo base_url("assets/img/account-icon.png") ?>" alt=""> -->
                                 <i class="fas fa-user"></i>
                              </a>
                              <?php if(isset($_SESSION['user_id'])) { ?>
                              <div class="dropdown-menu">
                                    <a href="<?=base_url("User/edit_profile");?>" class="dropdown-item">My Account</a>
                                    <a href="<?=base_url("Corder/track_order_form")?>" class="dropdown-item">Track your order</a>
                                    <a href="<?=base_url("Corder/my_order")?>" class="dropdown-item">Order History</a>
                                    <?php if($_SESSION['user_type'] == 1){?>
                                        <a href="<?=base_url("Admin_dashboard")?>" class="dropdown-item">Admin Panel</a>
                                    <?php } ?>
                                    <a href="<?=base_url().'Dashboard/logout_email'?>" class="dropdown-item">Logout</a>
                              </div>
                              <?php } ?>
                           </div>
                        </div>

                        <div class="cart_icon">
                           <a href="<?php echo base_url() ?>corder/cart_page" id="cartBtn" data-toggle="">
                              <!-- <img src="<?php //echo base_url() ?>assets/img/basket.png" alt="" id="basket-img"> -->
                              <i class="fas fa-shopping-cart" ></i>
                              <div class="cart_icon_text">
                                 <span id="add_to_cart_items" class="badge badge-pill badge-light b-r-50">0</span>
                              </div>
                           </a>
                        </div>

                        <div class="sidebar-button">
                           <button class="navbar-toggler" id="btn-sidebar"
                           class="p-0"
                           type="button" data-toggle="collapse"
                           data-target="#navbarSupportedContent" 
                           aria-controls="navbarSupportedContent"
                           aria-expanded="false" 
                           aria-label="Toggle navigation"
                           style="padding:0px;">
                              <!-- <img src="<?php //echo base_url() ?>assets/img/Menu-icon.png" alt=""> -->
                              <i class="fas fa-bars"></i>
                           </button>
                        </div>

                     </div>

                  </div>
               </div>
            </div>
         </div>
   </div>




<?php
   if($PageName == 'Home') {
      $this->load->view('include/banner', $BannerImages); 
   }
?>

<div class="wrapper">

<script type="text/javascript">
  //€  £
   const currency = '£';
   function getCookie(name) {
        return localStorage.getItem(name);
      // const value = `; ${document.cookie}`;
      // const parts = value.split(`; ${name}=`);
      // if(parts.length > 1){
      //    while(parts.length == 1)
      //       parts.shift();
      //    return (parts.pop()).split(";")[0];
      // }
   }
   function formatCurrency(total, toFixed = 2) {
     var neg = false;
     if(total < 0) {
       neg = true;
       total = Math.abs(total);
    }
    return (neg ? `-${currency} ` : `${currency}`) + parseFloat(total, 10).toFixed(toFixed).replace(/(\d)(?=(\d{3})+\.)/g, "$1,").toString();
 }
 $(document).ready(() => {
   //  var isWebNoteAvailable = $('body').find($('#websiteNote'));

  var urlVars = getUrlVars();
  var searchText = urlVars["q"];
  $(".dropdown").hover(function(){
      var dropdownMenu = $(this).children(".dropdown-menu");
      if(dropdownMenu.is(":visible")){
         dropdownMenu.parent().toggleClass("open");
      }
   });
  if(searchText){
    $("#q").val(searchText.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, ' '));
  }
  var selectedCat = urlVars["categoryId"];
  if(selectedCat){
    $("#cat-" + selectedCat).trigger("click");
  }
   loadCartData();
   $(document).on('keydown', '.quantity', function () {
      if(event.keyCode == 189)
        return false;
   });
   $(document).on('click', '.remove-item-from-cart', function () {
      removeItemFromShoppingCart($(this));
   });
//   $(document).on('click', '#cartBtn', function () {
//       loadShoppingCart();
//   });
   $(document).on('click', '.remove-cart', function () {
      $('#add_to_cart_items').addClass('cartAnimate');
      var productJson = $(this).data('json');
      removeAndUpdateFromCart(productJson, $(this));
      setTimeout(() => {
         $('#add_to_cart_items').removeClass('cartAnimate');
      }, 1000);

   });
   $(document).on('click', '.add-cart', function () {
      $('#add_to_cart_items').addClass('cartAnimate');
       var productJson = $(this).data('json');
       var quantity = parseFloat($(this).parent().parent().parent().find('.quantity')[0].value);
       if(!isNaN(quantity) && quantity > 0){
         var cart = getCookie('baskit');
         if(cart)
            cart = JSON.parse(cart);
         addOrUpdateCart(cart && cart.length > 0 ? cart : [], productJson, quantity, $(this))
         setTimeout(() => {
            $('#add_to_cart_items').removeClass('cartAnimate');
         }, 1000);
      }else{
         $.notify("Select a valid quantity, quantity must be greater then 0", "error");
         $('#add_to_cart_items').removeClass('cartAnimate');
      }
   });
   var baseUrl = "<?php echo base_url();?>";
   $(document).on('change', '.prodvari', function () {
        var currentElem = $(this);
        var eachProd = $(currentElem.closest('.each-prod')[0]);
        var productJson = eachProd.find('.add-cart').data('json');
        if(productJson){
          if(currentElem.val() == -1){
            var prodImg = $(eachProd.find('img')[0]);
            prodImg.fadeOut(400, function() {
              prodImg.attr('src', productJson.img);
            })
            .fadeIn(400);
            $(eachProd.find('.mainPrice')[0]).html(formatCurrency(productJson.price));
          }
          else{
            var selectedVarient = productJson.varient.filter(x=>{return x.VId == currentElem.val()});
            if(selectedVarient.length > 0){
              selectedVarient = selectedVarient[0];
              var prodImg = $(eachProd.find('img')[0]);
              if(selectedVarient.VImage){
                prodImg.fadeOut(400, function() {
                  prodImg.attr('src',baseUrl + selectedVarient.VImage);
                })
                .fadeIn(400);
              }else{
                prodImg.fadeOut(400, function() {
                  prodImg.attr('src', productJson.img);
                })
                .fadeIn(400);
              }
              $(eachProd.find('.mainPrice')[0]).html(formatCurrency(selectedVarient.VValue));
            }
          }
        }
   });
   $(document).on('click', '.qty-pls', function () {
      changeQtyOfProductAndPutInCart($(this), 'plus');      
   });
   $(document).on('click', '.qty-mns', function () {
      changeQtyOfProductAndPutInCart($(this), 'minus');

      var prodCountValue = $($(this).closest('.each-prod')[0]).find('.quantity')[0].value;
      if(prodCountValue == 0) {
         $('#add_to_cart_items').addClass('cartAnimate');
         setTimeout(() => {
            $('#add_to_cart_items').removeClass('cartAnimate');
         }, 1000);
      }
      
   });
});
var varientProducts = [];
function setVarientProducts(obj){

}
function changeVarient(){

}
function addOrUpdateCart(cart, productJson, quantity, addCartObj){
   var currentProduct = cart.filter((each)=>{return each.id == productJson.id});
   var oldQty = 0;
   if(currentProduct.length > 0){
      oldQty = currentProduct[0].quantity;
      currentProduct[0].quantity = quantity;
   }
   else{
      productJson.quantity = quantity;
      cart.push(productJson);
   }
   //document.cookie = `baskit=${JSON.stringify(cart)};path=/;`;
   localStorage.setItem('baskit', JSON.stringify(cart));
   // if(currentProduct.length > 0)
   //    $.notify(`${productJson.pName} quantity updated from ${oldQty} to ${currentProduct[0].quantity}`, "success");
   // else
   //    $.notify(`${productJson.pName} added into cart`, "success");
   $('#add_to_cart_items').html(cart.length);
   $(addCartObj.parent().find('.remove-cart')[0]).show();
   addCartObj.html('Update to Cart');
   if($(addCartObj.parent().find('.remove-cart')[0]).hasClass('remove-cart-main')){
      addCartObj.hide();
   }
   return true;
}
function removeAndUpdateFromCart(productJson, removeCartObj){
   var cart = getCookie('baskit');
   if(!cart)
      return true;
   cart = JSON.parse(cart);
   var cartExceptCurrentProduct = cart.filter((each)=>{return each.id != productJson.id});
   //var cookieString = `baskit=${JSON.stringify(cartExceptCurrentProduct)};path=/;`;
   if(cartExceptCurrentProduct.length == 0){
        localStorage.removeItem("baskit");
        // var oldDt = new Date(1);
        // cookieString += `expires=${oldDt}`;
   }
   //document.cookie = cookieString;
   localStorage.setItem("baskit", JSON.stringify(cartExceptCurrentProduct));
   $('#add_to_cart_items').html(cartExceptCurrentProduct.length);

   // removeCartObj.hide();
   // $(removeCartObj.parent().find('.quantity')[0]).val('');
   // $(removeCartObj.parent().find('.add-cart')[0]).html('Add to Cart');

   loadCartData();
   $.notify(`${productJson.pName} removed from cart`, "warn");
   return true;
}
function loadCartData(){
   var cart = getCookie('baskit');
   if(!cart)
      cart = '[]';
   cart = JSON.parse(cart);
   var allProducts = $('.each-prod');
   for (var i = 0; i < allProducts.length; i++) {
      var productJson = $($(allProducts[i]).find('.add-cart')[0]).data('json');
      if(!productJson)
         continue;
      var currentProduct = cart.filter((each)=>{return each.id == productJson.id});
      if(currentProduct.length > 0){
         $($(allProducts[i]).find('.remove-cart')[0]).show();
         $($(allProducts[i]).find('.quantity')[0]).val(currentProduct[0].quantity);
         $($(allProducts[i]).find('.add-cart')[0]).html('Update to Cart');
         if($($(allProducts[i]).find('.remove-cart')[0]).hasClass('remove-cart-main')){
            $($(allProducts[i]).find('.add-cart')[0]).hide();
         }
      }else{
         $($(allProducts[i]).find('.remove-cart')[0]).hide();
         $($(allProducts[i]).find('.quantity')[0]).val('1');
         $($(allProducts[i]).find('.add-cart')[0]).html('Add to Cart');
         if($($(allProducts[i]).find('.remove-cart')[0]).hasClass('remove-cart-main')){
            $($(allProducts[i]).find('.add-cart')[0]).show();
         }
      }
   }
   $('#add_to_cart_items').html(cart.length);
}
function changeQtyOfProductAndPutInCart(targetElem, operation){
   var prodContainer = $(targetElem.closest('.each-prod')[0]);
   var prodCountObj = prodContainer.find('.quantity')[0];
   if((!prodCountObj || isNaN(prodCountObj.value)) && prodCountObj.tagName == 'INPUT'){
      $.notify(`Please add a valid quantity`, "error");
      return false;
   }
   else{
      var qty = prodCountObj.value == "" ? 0 : prodCountObj.value;
      if(prodCountObj.tagName == 'P'){
        var tempQty = parseFloat(prodCountObj.innerHTML);
        if(!isNaN(tempQty)){
          qty = tempQty;
        }
        else{
          qty = 0;
        }
      }
      if(qty <= 0 && operation == 'minus')
         return false;
      prodCountObj.value = operation == 'plus' ? ++qty : --qty;
      if(prodCountObj.tagName == "P")
        prodCountObj.innerHTML = qty;
      var addCartObj = $(prodContainer.find('.add-cart')[0]);
      if(addCartObj && addCartObj.html() && addCartObj.html().toLocaleLowerCase() == 'add to cart'){
         return true;
      }
      var cart = getCookie('baskit');
      if(cart)
         cart = JSON.parse(cart);

      var dataJson = null;
      dataJson = addCartObj.data('json');
      if(!dataJson){
        var currentProdId = addCartObj.attr("pId");
        dataJson = cart.filter(function(each){return each.id == currentProdId});
        if(dataJson.length > 0)
          dataJson = dataJson[0];
      }
      if(qty == 0){
        if(window.location.href.toLocaleLowerCase().indexOf('corder/cart_page') != -1)
          prodContainer.remove();
        removeAndUpdateFromCart(dataJson, $(prodContainer.find('.remove-cart')[0]));
        return true;
      }else{
         addOrUpdateCart(cart && cart.length > 0 ? cart : [], 
            dataJson, 
            qty,
            addCartObj
            );
         return true;
      }
   }
}
function removeItemFromShoppingCart(currentElem){
   var productId = parseFloat(currentElem.data('id'));
   var prodName = currentElem.data('name');
   var cart = getCookie('baskit');
   if(cart)
      cart = JSON.parse(cart);
   var cartExceptCurrentProduct = cart.filter((each)=>{return each.id != productId});
   //var cookieString = `baskit=${JSON.stringify(cartExceptCurrentProduct)};path=/;`;
   if(cartExceptCurrentProduct.length == 0){
        localStorage.removeItem("baskit");
        // var oldDt = new Date(1);
        // cookieString += `expires=${oldDt}`;
   }
   //document.cookie = cookieString;
   localStorage.setItem("baskit", JSON.stringify(cartExceptCurrentProduct));
   currentElem.closest('.cart-single-elem').remove();
   $.notify(`${prodName} removed from cart`, "warn");
   if(cartExceptCurrentProduct.length == 0){
      var cartObj = $('#shoppingCartBody');
      if(cartObj && cartObj.length > 0)
         showEmptyResponse($(".cart-page"))
   }
   else{
    var totalP = 0;
    for (var i = 0; i < cartExceptCurrentProduct.length; i++) {
      totalP += parseFloat(cartExceptCurrentProduct[i].price) * parseFloat(cartExceptCurrentProduct[i].quantity);
    }
    $('#Grand-Total').html(totalP);
   }
   loadCartData();
}

   function showEmptyResponse(cartBody){
      if(cartBody)
        $(cartBody).hide();
      if(cartBody && cartBody[0])
        $(cartBody[0]).hide();
      $($('.empty-cart-page')[0]).show();
      $(document).on('click', '.checkout-btn', handleCheckout(event));
   }
   function handleCheckout(e){
    if(event)
      event.preventDefault();
      return false;
   }
   function emptyCart(){
      var oldDt = new Date(1);
      //document.cookie = `baskit=[];path=/;expires=${oldDt}`;
      localStorage.removeItem("baskit");
      showEmptyResponse($('.cart-page'));
      loadCartData();
   }
   function changeSelectedCat(currentElem){
      $('#categoryId').val($(currentElem).data('value'));
      $('#q').attr("placeholder" , $(currentElem).text());
   }
   
   function getUrlVars(){
      var vars = [], hash;
      var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
      for(var i = 0; i < hashes.length; i++)
      {
          hash = hashes[i].split('=');
          vars.push(hash[0]);
          vars[hash[0]] = hash[1];
      }
      return vars;
  }
</script>
   <!-- Cart Scripts End -->
<style>
     .ui-autocomplete {
      max-height: 200px;
      overflow-y: auto;
      overflow-x: hidden;
      padding-right: 1px;
      font-size: 13px;
      position: fixed;
      overflow: auto;
   }
</style>
 <!-- Auto Complete search script START-->
<script type='text/javascript'>
  $(document).ready(function(){
    //$('#q').focus();
     // $("#q").autocomplete({
     //    source: function( request, response )
     //    {
     //         $.ajax({
     //            url: "<?php echo base_url();?>Autocomplete/userdata",
     //            type: 'post',
     //            dataType: "json",
     //            data: {
     //              search: request.term
     //            },
     //            success: function( data ) 
     //            {
     //              response( data );
     //            }
     //         });
     //    },
     //    select: function (values, ui) {
     //         $('#q').val(ui.item.label);
     //         return false;
     //    }
     // });

    var allTxt = $(".card-text, .product-card-title");
    for (var i = 0; i < allTxt.length; i++) {
      $(allTxt[i]).attr("data-toggle", "tooltip");
    }
    $('[data-toggle="tooltip"]').tooltip();
    // $("#q").click(function() {
    //   if(window.location.href.toLocaleLowerCase().indexOf("cproduct") == -1)
    //     window.location.href = "<?php echo base_url('cproduct/products?q=&categoryId=');?>";
    // });
    $("#q").keydown(function() {
      var code = event.keyCode;
      if(code >= 65 && code <= 90  || code >= 97 && code <= 122 || code >= 48 && code <= 57)
      {
        if(window.location.href.toLocaleLowerCase().indexOf("cproduct") == -1)
          $("#searchform").submit();
      }
    });
  });

  function WindowsResizeFunc() {
    if ($(window).width() >  768) {
      $(".edibles-main .product-category").addClass('show');
      $("#InnerPageMenuContent").addClass('show');
    }
    else {
      $(".edibles-main .product-category").removeClass('show');
      $("#InnerPageMenuContent").removeClass('show');
    }
  } 

</script>
 